import {
  Program,
  AnchorProvider,
  web3,
  workspace,
} from "@coral-xyz/anchor";

const provider = AnchorProvider.env();
const program = workspace.Baseroot as Program;

describe("Baseroot Program", () => {
  it("should upload research successfully", async () => {
    console.log("Testing upload_research function...");

    // Araştırmayı yükleyecek kişi
    const author = provider.wallet;

    // Yeni research hesabı için PDA oluştur (Program Derived Address)
    const [researchPDA] = web3.PublicKey.findProgramAddressSync(
      [Buffer.from("research"), author.publicKey.toBuffer()],
      program.programId
    );

    console.log(`Research PDA: ${researchPDA.toBase58()}`);

    try {
      // Araştırma yükleme işlemi
      const tx = await program.methods
        .uploadResearch("CRISPR Teknolojisi", "QmWxyz123ABCipfshash")
        .accounts({
          research: researchPDA,
          author: author.publicKey,
          systemProgram: web3.SystemProgram.programId,
        })
        .signers([])
        .rpc();
  
      console.log("✅ Research uploaded successfully!");
      console.log(`Transaction ID: ${tx}`);  // Başarıyla gerçekleşen işlemin ID'sini yazdır

      // İşlem başarılıysa, transaction ID'yi kontrol et
      const txDetails = await provider.connection.getTransaction(tx);
      console.log("Transaction details: ", txDetails);
    } catch (err) {
      console.error("Error occurred during uploadResearch:", err);
    }
  });
});
