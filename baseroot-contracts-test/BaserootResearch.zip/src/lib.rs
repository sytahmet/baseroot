use anchor_lang::prelude::*;

declare_id!("A3XMXeeCUZUjorebtigwemkjXFergEKWXBYXKmsJTnhF"); // İlk başta böyle kalabilir

#[program]
pub mod baseroot {
    use super::*;

    pub fn upload_research(
        ctx: Context<UploadResearch>,
        title: String,
        ipfs_hash: String,
    ) -> Result<()> {
        let research = &mut ctx.accounts.research;
        research.author = *ctx.accounts.author.key;
        research.title = title;
        research.ipfs_hash = ipfs_hash;
        research.timestamp = Clock::get()?.unix_timestamp;
        Ok(())
    }
}

#[derive(Accounts)]
pub struct UploadResearch<'info> {
    #[account(init, payer = author, space = 8 + 32 + 4 + 100 + 4 + 100 + 8)]
    pub research: Account<'info, Research>,
    #[account(mut)]
    pub author: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[account]
pub struct Research {
    pub author: Pubkey,
    pub title: String,
    pub ipfs_hash: String,
    pub timestamp: i64,
}
