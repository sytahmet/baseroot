use anchor_lang::prelude::*;

declare_id!("9jUTAXqafppfZiPWkJYKPnCuuRAe1gDUEYRwLiLwWdQ2"); // Deploy sonrası program ID'n ile güncelle

#[program]
pub mod baseroot_dao {
    use super::*;

    // Yeni bir vote account oluşturulurken, oy sayıları sıfırlanır.
    pub fn initialize_vote(ctx: Context<InitializeVote>, research_id: String) -> Result<()> {
        let vote_account = &mut ctx.accounts.vote_account;
        vote_account.research_id = research_id;
        vote_account.yes_votes = 0;
        vote_account.no_votes = 0;
        vote_account.voters = Vec::new();
        Ok(())
    }

    // Kullanıcının olumlu veya olumsuz oy verebileceği fonksiyon
    pub fn cast_vote(ctx: Context<CastVote>, vote_yes: bool) -> Result<()> {
        let vote_account = &mut ctx.accounts.vote_account;
        let voter = ctx.accounts.user.key();

        // Aynı kullanıcının tekrar oy kullanmasını engelle
        if vote_account.voters.contains(&voter) {
            return Err(DaoError::AlreadyVoted.into());
        }

        // Oy türüne göre sayacı güncelle
        if vote_yes {
            vote_account.yes_votes = vote_account.yes_votes.checked_add(1).unwrap();
        } else {
            vote_account.no_votes = vote_account.no_votes.checked_add(1).unwrap();
        }
        
        vote_account.voters.push(voter);
        Ok(())
    }
}

#[derive(Accounts)]
#[instruction(research_id: String)]
pub struct InitializeVote<'info> {
    #[account(
        init,
        payer = user,
        space = 8 + VoteAccount::LEN,
        seeds = [b"vote_account", research.key().as_ref()],
        bump
    )]
    pub vote_account: Account<'info, VoteAccount>,

    /// CHECK: Sadece referans için kullanıyoruz. (Araştırmanın hesabı veya ID'si)
    pub research: AccountInfo<'info>,

    #[account(mut)]
    pub user: Signer<'info>,

    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct CastVote<'info> {
    #[account(
        mut,
        seeds = [b"vote_account", research.key().as_ref()],
        bump
    )]
    pub vote_account: Account<'info, VoteAccount>,

    /// CHECK: Sadece referans için.
    pub research: AccountInfo<'info>,

    #[account(mut)]
    pub user: Signer<'info>,
}

#[account]
pub struct VoteAccount {
    pub research_id: String,   // Araştırmanın ID'si
    pub yes_votes: u32,        // Olumlu oy sayısı
    pub no_votes: u32,         // Olumsuz oy sayısı
    pub voters: Vec<Pubkey>,   // Oy kullanan cüzdan adresleri
}

// Hesap alanı hesabı için toplam alan hesabı (discriminator + veri boyutu)
impl VoteAccount {
    // research_id: max 32 byte (örnek sabit), yes_votes: 4, no_votes: 4,
    // voters: 4 (length) + 32 * max 100 oy kullanıcısı (örneğin)
    pub const LEN: usize = 32 + 4 + 4 + (4 + 32 * 100);
}

#[error_code]
pub enum DaoError {
    #[msg("You have already voted on this research.")]
    AlreadyVoted,
}
