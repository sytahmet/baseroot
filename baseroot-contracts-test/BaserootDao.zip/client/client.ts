import * as web3 from "@solana/web3.js";
import * as anchor from "@coral-xyz/anchor";
import * as anchor from "@project-serum/anchor";
import { SystemProgram } from "@solana/web3.js";
import type { BaserootDao } from "../target/types/baseroot_dao";

// Configure the client to use the local cluster
anchor.setProvider(anchor.AnchorProvider.env());

const program = anchor.workspace.BaserootDao as anchor.Program<BaserootDao>;


const provider = anchor.Provider.env();
anchor.setProvider(provider);

const program = anchor.workspace.BaserootDao;

async function initializeVote() {
  const researchId = "Research_123";
  const [voteAccount, voteAccountBump] = await anchor.web3.PublicKey.findProgramAddress(
    [Buffer.from("vote_account"), Buffer.from(researchId)],
    program.programId
  );

  // Oylama başlatma
  await program.rpc.initializeVote(researchId, {
    accounts: {
      voteAccount,
      user: provider.wallet.publicKey,
      research: voteAccount,
      systemProgram: SystemProgram.programId,
    },
  });

  console.log(`Vote Account Initialized: ${voteAccount.toString()}`);
}

async function castVote() {
  const researchId = "Research_123";
  const voteYes = true;

  const [voteAccount, voteAccountBump] = await anchor.web3.PublicKey.findProgramAddress(
    [Buffer.from("vote_account"), Buffer.from(researchId)],
    program.programId
  );

  // Oy kullanma
  await program.rpc.castVote(voteYes, {
    accounts: {
      voteAccount,
      research: voteAccount,
      user: provider.wallet.publicKey,
    },
  });

  console.log(`Vote casted for Research ID: ${researchId}`);
}

async function main() {
  await initializeVote();
  await castVote();
}

main().catch((err) => {
  console.error(err);
});
