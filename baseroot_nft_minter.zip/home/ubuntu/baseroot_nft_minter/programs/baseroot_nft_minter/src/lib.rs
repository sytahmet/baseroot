use anchor_lang::prelude::*;
use anchor_spl::token::{self, MintTo, Token, TokenAccount, Mint};
use mpl_token_metadata::instruction::{create_metadata_accounts_v3, create_master_edition_v3};
use solana_program::program::invoke_signed;

declare_id!("Fg6PaFpoGXkYsidMpWTK6W2BeZ7FEfcYkg476zPFsLnS"); // Placeholder, will be updated after deployment

#[program]
pub mod baseroot_nft_minter {
    use super::*; 

    pub fn mint_research_nft(
        ctx: Context<MintResearchNft>,
        title: String,
        symbol: String,
        uri: String, // URI to the off-chain JSON metadata
    ) -> Result<()> {
        msg!("Minting Research NFT: {}", title);
        msg!("Symbol: {}", symbol);
        msg!("Metadata URI: {}", uri);

        // 1. Mint the token
        let cpi_accounts = MintTo {
            mint: ctx.accounts.mint_account.to_account_info(),
            to: ctx.accounts.token_account.to_account_info(),
            authority: ctx.accounts.minter.to_account_info(),
        };
        let cpi_program = ctx.accounts.token_program.to_account_info();
        let cpi_ctx = CpiContext::new(cpi_program, cpi_accounts);
        token::mint_to(cpi_ctx, 1)?; // Mint 1 token for the NFT
        msg!("Token minted successfully.");

        // 2. Create Metadata Account using Metaplex
        let creator = vec![
            mpl_token_metadata::state::Creator {
                address: ctx.accounts.minter.key(),
                verified: true,
                share: 100,
            },
        ];

        let metadata_instruction = create_metadata_accounts_v3(
            ctx.accounts.token_metadata_program.key(),
            ctx.accounts.metadata_account.key(),
            ctx.accounts.mint_account.key(),
            ctx.accounts.minter.key(),    // Mint authority
            ctx.accounts.minter.key(),    // Payer
            ctx.accounts.minter.key(),    // Update authority
            title.clone(),
            symbol.clone(),
            uri.clone(),
            Some(creator),
            0, // Seller fee basis points
            true, // Update authority is signer
            true, // Is mutable
            None, // Collection
            None, // Uses
            None, // Collection Details
        );

        invoke_signed(
            &metadata_instruction,
            &[
                ctx.accounts.metadata_account.to_account_info(),
                ctx.accounts.mint_account.to_account_info(),
                ctx.accounts.minter.to_account_info(), // Mint_authority
                ctx.accounts.minter.to_account_info(), // Payer
                ctx.accounts.minter.to_account_info(), // Update_authority
                ctx.accounts.system_program.to_account_info(),
                ctx.accounts.rent.to_account_info(),
                ctx.accounts.token_metadata_program.to_account_info(),
            ],
            &[], // No signer seeds needed if payer is the signer
        )?;
        msg!("Metadata account created successfully.");

        // 3. Create Master Edition Account for the NFT (makes it a non-fungible token)
        let master_edition_instruction = create_master_edition_v3(
            ctx.accounts.token_metadata_program.key(),
            ctx.accounts.master_edition_account.key(),
            ctx.accounts.mint_account.key(),
            ctx.accounts.minter.key(), // Update authority
            ctx.accounts.minter.key(), // Mint authority
            ctx.accounts.metadata_account.key(),
            ctx.accounts.minter.key(), // Payer
            Some(0), // Max supply: 0 for a non-fungible token
        );

        invoke_signed(
            &master_edition_instruction,
            &[
                ctx.accounts.master_edition_account.to_account_info(),
                ctx.accounts.mint_account.to_account_info(),
                ctx.accounts.minter.to_account_info(), // Update_authority
                ctx.accounts.minter.to_account_info(), // Mint_authority for master edition
                ctx.accounts.minter.to_account_info(), // Payer
                ctx.accounts.metadata_account.to_account_info(),
                ctx.accounts.token_program.to_account_info(),
                ctx.accounts.system_program.to_account_info(),
                ctx.accounts.rent.to_account_info(),
                ctx.accounts.token_metadata_program.to_account_info(),
            ],
            &[], // No signer seeds needed
        )?;
        msg!("Master Edition account created successfully. NFT minting complete.");

        Ok(())
    }
}

#[derive(Accounts)]
pub struct MintResearchNft<'info> {
    // Account that will hold the minted NFT
    #[account(mut)]
    pub mint_account: Account<'info, Mint>,
    // User's token account for the new NFT
    #[account(mut)]
    pub token_account: Account<'info, TokenAccount>,
    // The account creating the NFT (payer and authority)
    #[account(mut)]
    pub minter: Signer<'info>,
    // Metaplex Token Metadata Program
    /// CHECK: This is not dangerous because we don't read or write from this account
    #[account(address = mpl_token_metadata::ID)]
    pub token_metadata_program: AccountInfo<'info>,
    // Account to store metadata
    /// CHECK: This is not dangerous because we are creating this account
    #[account(mut)]
    pub metadata_account: AccountInfo<'info>,
    // Account for the Master Edition (makes it an NFT)
    /// CHECK: This is not dangerous because we are creating this account
    #[account(mut)]
    pub master_edition_account: AccountInfo<'info>,
    // System Program
    pub system_program: Program<'info, System>,
    // Token Program
    pub token_program: Program<'info, Token>,
    // Rent Sysvar
    pub rent: Sysvar<'info, Rent>,
}

// TODO: Add events for indexing off-chain
// TODO: Add more detailed error handling

